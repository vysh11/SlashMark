Unzip and Place your dataset files here in the dataset folder.

There should be four files with these names (make sure the names match):

dataset
|_ train-images-idx3-ubyte
|_ train-labels-idx1-ubyte
|_ t10k-images-idx3-ubyte
|_ t10k-labels-idx1-ubyte
